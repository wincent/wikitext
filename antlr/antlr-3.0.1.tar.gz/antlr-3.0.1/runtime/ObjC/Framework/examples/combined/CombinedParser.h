// $ANTLR 3.0 Combined.g 2007-07-25 20:12:40

#import <Cocoa/Cocoa.h>
#import <ANTLR/ANTLR.h>



#pragma mark Tokens
#define CombinedParser_INT	5
#define CombinedParser_WS	6
#define CombinedParser_EOF	-1
#define CombinedParser_ID	4

#pragma mark Dynamic Global Scopes

#pragma mark Dynamic Rule Scopes

#pragma mark Rule Return Scopes


@interface CombinedParser : ANTLRParser {

			

 }


- (void) stat;
- (void) identifier;



@end