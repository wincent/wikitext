// $ANTLR 3.0 T.g 2007-07-25 20:12:43

#import <Cocoa/Cocoa.h>
#import <ANTLR/ANTLR.h>


#pragma mark Rule return scopes start
#pragma mark Rule return scopes end

#pragma mark Tokens
#define TLexer_INT	5
#define TLexer_EOF	-1
#define TLexer_WS	6
#define TLexer_Tokens	8
#define TLexer_T7	7
#define TLexer_ID	4

@interface TLexer : ANTLRLexer {
}


- (void) mT7;
- (void) mID;
- (void) mINT;
- (void) mWS;
- (void) mTokens;



@end